import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Map<Integer,Integer> map=new HashMap<Integer,Integer>();
		int sum=0,i,pnum=0,flag=0;
		String opt;
		Scanner sc=new Scanner(System.in);
		
		/*Iterator it=list.iterator();
		
		while(it.hasNext())
		{
			sum+=it.next());
		}*/
		do
		{
				System.out.println("Enter your choice:");
				System.out.println("1.Load Truck\n2.Load additional parcel(s)\n3.Unload parcel(s)\n4.Unload entire truck\n5.Exit");
				int ch=sc.nextInt();
				switch(ch)
				{
					case 1:
						System.out.println("------Loading Truck------");
						System.out.println("Enter the number of parcels");
						int num=sc.nextInt();
						System.out.println("Enter the serial number and weight of each parcel");
						for(i=0;i<num;i++)
						{
							map.put(sc.nextInt(),sc.nextInt());
						}
						break;
					case 2:
						System.out.println("------Loading parcel(s)------");
						System.out.println("Enter number of parcels to load:");
						int add=sc.nextInt();
						System.out.println("Enter the serial number and weight of the parcel(s):");
						for(i=0;i<add;i++)
						{
							map.put(sc.nextInt(),sc.nextInt());
						}
						break;
					case 3:
						System.out.println("------Unloading parcel(s)------");
						System.out.println("Enter number of parcel(s) to unload:");
						int delnum=sc.nextInt();
						System.out.println("Enter the serial number of the parcel(s) to unload:");
						for(int j=0;j<delnum;j++)
						{
							int del=sc.nextInt();
							map.remove(del);
						}
						break;
					case 4:
						System.out.println("------Unload Entire Truck------");
						map.clear();
						break;
					case 5:
						System.out.println("------Exiting------");
						for(Map.Entry<Integer,Integer> entry : map.entrySet())
						{
							sum+=entry.getValue();
							pnum++;
						}
						System.out.println("The number of parcels on the truck is: "+pnum);
						System.out.println("The weight of the parcels on the truck is: "+sum);
						return;
				}
				System.out.println("Do you want to continue?(yes/no)");
				sc.nextLine();
				opt=sc.nextLine();
		}while(opt.equalsIgnoreCase("Yes"));
		
		
	}

}
